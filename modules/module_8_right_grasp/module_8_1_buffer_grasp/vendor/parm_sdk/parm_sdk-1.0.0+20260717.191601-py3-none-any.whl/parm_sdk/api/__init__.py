"""API subpackage — command enums, exceptions, models."""

from parm_sdk.api.exceptions import ParmAPIError

__all__ = ["ParmAPIError"]
