"""所有设备的统一异常体系。

错误码空间（C++ 侧 error_code.hpp）：
  0      ERR_SUCCESS
  1      ERR_UNKNOWN
  1001   ERR_INVALID_ARM_ID  → ParameterError
  1002   ERR_ARM_NOT_AVAILABLE → StateError
  1003   ERR_ARM_DISABLED    → ArmNotEnabledError
  1005   ERR_TASK_COLLISION  → CollisionError
  1006   ERR_ESTOP_LATCHED   → EmergencyStopError

预留（其他设备）：
  4000+ : Gripper
  5000+ : Head
  6000+ : ForceSensor
"""


class ParmAPIError(Exception):
    """所有设备异常的基类。"""

    error_code: int = 1

    def __init__(self, message: str = "", *, error_code: int | None = None) -> None:
        super().__init__(message)
        self.message = message
        if error_code is not None:
            self.error_code = error_code

    def __str__(self) -> str:
        return self.message


class ParameterError(ParmAPIError):
    error_code = 1001


class StateError(ParmAPIError):
    error_code = 1002


class ArmNotEnabledError(ParmAPIError):
    error_code = 1003


class CollisionError(ParmAPIError):
    error_code = 1005


class EmergencyStopError(ParmAPIError):
    error_code = 1006


class HeadError(ParmAPIError):
    """Head（PTZ 云台）异常占位。

    C++ 侧错误码空间：5000+。当前 SDK 端抛 `ParmAPIError` 基类；
    本类作为类型标注用，待 C++ 错误码定稿后补充。
    """

    error_code = 5001


class GripperError(ParmAPIError):
    """Gripper（多夹爪）异常占位。

    C++ 侧错误码空间：4000+。
    """

    error_code = 4001


class ForceSensorError(ParmAPIError):
    """ForceSensor（力传感器）异常占位。

    C++ 侧错误码空间：6000+。
    """

    error_code = 6001


__all__ = [
    "ParmAPIError",
    "ParameterError",
    "StateError",
    "ArmNotEnabledError",
    "CollisionError",
    "EmergencyStopError",
    "HeadError",
    "GripperError",
    "ForceSensorError",
]
