"""Arm (mechanical arm) API definitions."""

from parm_sdk.api.arm.commands import ArmCommand

__all__ = ["ArmCommand"]
