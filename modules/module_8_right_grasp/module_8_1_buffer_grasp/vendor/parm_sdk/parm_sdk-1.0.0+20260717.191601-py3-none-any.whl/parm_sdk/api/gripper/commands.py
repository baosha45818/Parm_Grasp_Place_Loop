"""Gripper（多夹爪）命令枚举 — value 与 wire `action` 字符串一致。"""

from enum import Enum


class GripperCommand(str, Enum):
    """夹爪命令枚举。"""

    GET_STATUS = "get_status"
    INIT = "init"
    MOVE = "move"


__all__ = ["GripperCommand"]