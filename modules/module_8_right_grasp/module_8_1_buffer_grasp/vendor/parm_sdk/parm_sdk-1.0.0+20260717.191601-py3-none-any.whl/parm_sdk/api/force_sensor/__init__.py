"""ForceSensor（力传感器）API definitions."""

from parm_sdk.api.force_sensor.commands import ForceSensorCommand

__all__ = ["ForceSensorCommand"]
