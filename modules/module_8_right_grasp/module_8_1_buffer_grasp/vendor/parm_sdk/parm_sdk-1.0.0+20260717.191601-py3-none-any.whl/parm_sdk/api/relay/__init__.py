"""Relay（继电器）API definitions."""

from parm_sdk.api.relay.commands import RelayCommand

__all__ = ["RelayCommand"]