"""机械臂命令枚举 — wire name 与 C++ 端 CommandType 枚举保持一致。"""

from enum import Enum


class ArmCommand(str, Enum):
    """机械臂命令枚举。value 是 wire name（发送给 server 的字符串）。

    注意：
      - EXECUTE_TRAJECTORY 的 wire name 是 "follow_trajectory"，
        但 SDK 层 Python 端仍叫 follow_trajectory。
    """

    # 基础
    ENABLE = "enable"
    DISABLE = "disable"
    GET_ROBOT_STATE = "get_state"

    # 运动
    MOVE_J = "move_j"
    MOVE_L = "move_l"
    EXECUTE_TRAJECTORY = "follow_trajectory"
    CANCEL_TASK = "cancel_task"

    # Servo
    SERVO_J = "servo_j"
    SERVO_L = "servo_l"
    START_SERVO_POSE = "start_servo_pose"
    STOP_SERVO_POSE = "stop_servo_pose"
    SERVO_POSE = "servo_pose"

    # 录制
    START_RECORD = "start_record"
    STOP_RECORD = "stop_record"

    # 示教
    START_ADMITTANCE_TEACH = "start_admittance_teach"
    STOP_ADMITTANCE_TEACH = "stop_admittance_teach"
    START_TEACH = "start_teach"
    STOP_TEACH = "stop_teach"

    # 安全
    ACTIVATE_ESTOP = "activate_estop"
    RELEASE_ESTOP = "release_estop"
    CONFIRM_RECOVERY = "confirm_recovery"   # wire name；SDK 方法名 ``clear_error``
