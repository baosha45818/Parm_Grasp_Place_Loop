"""Relay（继电器）命令枚举 — value 与 wire `cmd` 字符串一致。"""

from enum import Enum


class RelayCommand(str, Enum):
    """继电器命令枚举。"""

    SET = "set"


__all__ = ["RelayCommand"]