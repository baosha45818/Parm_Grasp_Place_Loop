"""ForceSensor（力传感器）命令枚举 — 占位。

M4 阶段 ForceSensor 仅有 PUB/SUB 状态订阅路径，无 REQ/REP 命令通道。
枚举保留为空容器，待 C++ 侧追加命令（如 tare/calibrate）时再扩展。
"""

from enum import Enum


class ForceSensorCommand(str, Enum):
    """力传感器命令枚举（占位，无成员）。"""


__all__ = ["ForceSensorCommand"]
