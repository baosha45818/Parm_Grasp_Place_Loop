"""Head（PTZ gimbal）API definitions."""

from parm_sdk.api.head.commands import HeadCommand

__all__ = ["HeadCommand"]