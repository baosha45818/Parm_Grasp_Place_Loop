"""Head（PTZ 云台）命令枚举 — wire name 与 C++ 端保持一致。"""

from enum import Enum


class HeadCommand(str, Enum):
    """云台命令枚举。value 是 wire name。"""

    PING = "ping"

    # 初始化 / 归位
    INIT = "init"
    HOME = "home"

    # 位置指令
    MOVE_TO = "move_to"
    LOOK_LEFT = "look_left"
    LOOK_RIGHT = "look_right"

    # 表达性动作
    NOD = "nod"
    SHAKE = "shake"

    # 急停
    EMERGENCY_STOP = "emergency_stop"

    # 状态 / 关停
    GET_STATUS = "get_status"
    SHUTDOWN = "shutdown"