"""Planner 命令 / 字段常量 — value 与 wire 字面量一致。

Planner 实际上挂了三个独立服务（轨迹规划 / TF 查询 / 路径点管理），
对应三个端口。本枚举收集所有 wire 层 action / 字段名常量，方便 SDK
内部统一引用、避免硬编码字符串散落各处。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum


# ---------- waypoint service (port 5610) ----------
class WaypointAction(str, Enum):
    GET = "get"
    ADD = "add"
    UPDATE = "update"
    DELETE = "delete"
    LIST = "list"


# ---------- tf service (port 5609) ----------
class TfAction(str, Enum):
    GET_ALL_FRAMES = "get_all_frames"
    LOOKUP_TRANSFORM = "lookup_transform"


# ---------- trajectory planner service (port 5604) ----------
class TrajectoryPlannerAction(str, Enum):
    PLAN = "plan_trajectory"  # 实际协议中直接发 waypoints dict，无需 action 字段


# ---------- 路点字段常量 ----------
WAYPOINT_TYPE_JOINT = "joint"
WAYPOINT_TYPE_CART = "cart"

# planner 类型常量。
PLANNER_PTP = "ptp"
PLANNER_LIN = "lin"
PLANNER_OMPL = "ompl"


# ---------- TOPP 时间参数化配置 ----------
@dataclass
class TOPPConfig:
    """TOPP（Time-Optimal Path Parameterization）时间参数化参数。

    wire 字段名（与 parm_mtc 服务端约定一致）。所有字段都有合理默认值；
    全部 ``None`` 时用 :attr:`default` 返回默认配置。

    字段：
        max_vel_factor: 最大速度比例（默认 0.1）
        max_acc_factor: 最大加速度比例（默认 0.1）
        final_phase_ratio: 末段比例（默认 0.05）
        final_phase_oversample: 末段过采样倍数（默认 2.0）
    """

    max_vel_factor: float = 0.1
    max_acc_factor: float = 0.1
    final_phase_ratio: float = 0.05
    final_phase_oversample: float = 2.0

    def to_wire(self) -> dict[str, float]:
        """转 wire 层 dict（发给服务端的格式）。"""
        return asdict(self)

    @classmethod
    def default(cls) -> "TOPPConfig":
        """默认配置：服务端缺省值（相当于不传 topp）。"""
        return cls()


class PlannerAction(str, Enum):
    """统一聚合：方便外部 ``from parm_sdk.api.planner import PlannerAction``。"""

    WAYPOINT_GET = "waypoint.get"
    WAYPOINT_ADD = "waypoint.add"
    WAYPOINT_UPDATE = "waypoint.update"
    WAYPOINT_DELETE = "waypoint.delete"
    WAYPOINT_LIST = "waypoint.list"
    TF_GET_ALL_FRAMES = "tf.get_all_frames"
    TF_LOOKUP_TRANSFORM = "tf.lookup_transform"
    TRAJECTORY_PLAN = "trajectory.plan"


__all__ = [
    "PlannerAction",
    "WaypointAction",
    "TfAction",
    "TrajectoryPlannerAction",
    "WAYPOINT_TYPE_JOINT",
    "WAYPOINT_TYPE_CART",
    "PLANNER_PTP",
    "PLANNER_LIN",
    "PLANNER_OMPL",
    "TOPPConfig",
]