"""统一日志入口。"""

from __future__ import annotations

import logging

_LOGGER_NAME = "parm_sdk"


def set_log_level(level: str | int) -> None:
    """设置 parm_sdk logger 的日志级别。

    影响 parm_sdk 及其所有子 logger（未显式设置 level 的子 logger 会继承）。

    Args:
        level: 日志级别。可以是 logging 常量（logging.DEBUG）或字符串（"DEBUG"）。
    """
    logging.getLogger(_LOGGER_NAME).setLevel(level)


__all__ = ["set_log_level"]
