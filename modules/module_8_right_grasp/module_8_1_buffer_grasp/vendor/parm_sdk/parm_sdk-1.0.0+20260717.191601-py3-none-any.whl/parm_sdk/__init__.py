"""parm_sdk — unified Python SDK for parm robotic devices.

Top-level imports are deliberately split:

- :data:`__version__` and :func:`set_log_level` are eagerly imported so
  ``import parm_sdk`` never touches optional runtime dependencies.
- :class:`Arm` (and any future device class that requires ZMQ) is lazy
  via :func:`__getattr__`. Accessing ``parm_sdk.Arm`` without pyzmq
  installed raises :class:`ImportError` and emits a one-line log
  reminder pointing at the ``[zmq]`` extra — see :mod:`parm_sdk.logging`.

:data:`__version__` is read from installed package metadata at import
time (single source of truth: ``pyproject.toml``'s ``[project] version``).
源码模式下 (``pip install -e .``) 也可正常工作。
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _pkg_version

from parm_sdk.logging import set_log_level

try:
    __version__ = _pkg_version("parm-sdk")
except PackageNotFoundError:
    # 直接 ``python -c "import sys; sys.path.insert(0, '...'); import parm_sdk"``
    # 这种未安装的场景里 __version__ 拿不到 wheel/egg 元数据。
    # 仍然从 pyproject.toml 兜底读，方便开发者本地 sanity-check。
    __version__ = _read_version_from_pyproject()
del _pkg_version


def _read_version_from_pyproject() -> str:
    """从仓库根 ``pyproject.toml`` 的 ``[project] version`` 兜底读取。

    仅在包未安装（即 ``importlib.metadata`` 找不到 parm-sdk）的场景下生效。
    """
    import os
    import re

    here = os.path.dirname(os.path.abspath(__file__))
    pyproject = os.path.normpath(os.path.join(here, os.pardir, os.pardir, "pyproject.toml"))
    try:
        with open(pyproject, encoding="utf-8") as fh:
            for line in fh:
                m = re.match(r"""^version\s*=\s*["']([^"']+)["']""", line)
                if m:
                    return m.group(1)
    except OSError:
        pass
    return "unknown"


_LAZY_EXPORTS: dict[str, tuple[str, str]] = {
    "Arm": ("parm_sdk.sdk.arm", "Arm"),
    "Head": ("parm_sdk.sdk.head", "Head"),
    "Gripper": ("parm_sdk.sdk.gripper", "Gripper"),
    "ForceSensor": ("parm_sdk.sdk.force_sensor", "ForceSensor"),
    "Planner": ("parm_sdk.sdk.planner", "Planner"),
}


def __getattr__(name: str):
    if name in _LAZY_EXPORTS:
        module_path, attr_name = _LAZY_EXPORTS[name]
        try:
            module = __import__(module_path, fromlist=[attr_name])
        except ImportError as exc:
            missing = getattr(exc, "name", "") or ""
            if missing == "zmq" or "zmq" in str(exc):
                # Stdlib ``logging`` is resolved by full path here because a
                # top-level ``import logging`` in this file would be shadowed
                # by the ``parm_sdk.logging`` submodule (submodules of the
                # current package are bound into the package's namespace at
                # import time).
                __import__("logging").getLogger("parm_sdk").error(
                    "Cannot import %s: pyzmq is required for ZMQ-based "
                    "devices. Install it with: pip install 'parm-sdk[zmq]'",
                    name,
                )
            raise
        return getattr(module, attr_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted({*globals().keys(), *_LAZY_EXPORTS.keys()})


__all__ = ["Arm", "Head", "Gripper", "ForceSensor", "Planner", "set_log_level", "__version__"]
