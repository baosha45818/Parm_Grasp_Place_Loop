"""Planner 高级 API —— 轨迹规划 / 路径点查询 / TF 查询的 Python 客户端。

Planner 实际上是三个独立 ZMQ 服务的统一封装：

================ ============= ==================================
子服务           默认端口        主要功能
================ ============= ==================================
轨迹规划          ``5604``       关节 / 笛卡尔路点 → 平滑轨迹
TF 查询           ``5609``       坐标系列表 / 坐标变换
路径点管理        ``5610``       路点 CRUD + 列表
================ ============= ==================================

三个服务都用 ``REQ/REP``（服务端 ROUTER）——``success`` / ``message`` /
``data`` envelope 与 :class:`Relay` 的 ``{"success", "message"}`` 不一样：
Planner 服务保留 ``data`` 字段作为业务负载。

wire 字段详见 :doc:`docs/sdk_docs/planner.md` 或
`parm_mtc/doc/Parm API V1.0.3.md <https://...>`_。
"""

from __future__ import annotations

import logging
from typing import Any

from parm_sdk.api.exceptions import ParmAPIError
from parm_sdk.api.planner.commands import TOPPConfig
from parm_sdk.sdk.transport import BaseZMQClient

_LOGGER = logging.getLogger("parm_sdk.sdk.planner")

_SERVER_AVAILABLE_TIMEOUT_S = 0.1

# 默认端口（与 parm_mtc 服务约定一致；环境变量或 kwargs 可覆盖）。
DEFAULT_TRAJECTORY_PORT = 5604
DEFAULT_TF_PORT = 5609
DEFAULT_WAYPOINT_PORT = 5610

# ---- 字段范围常量 ----
_JOINT_PLANNERS = ("ptp", "lin", "ompl")
_CART_PLANNERS = ("ptp", "lin")
_WAYPOINT_TYPES = ("joint", "cart")

_DEFAULT_VEL_SCALE = 0.1
_DEFAULT_ACC_SCALE = 0.1

# 默认命令超时（秒）：plan / tf / waypoint 三个子服务的所有方法都用 30s。
# 1s 太短（BaseZMQClient 默认）—— 规划求解在负载大时可能 >1s；IK + 路径优化等
# 也可能超过。30s 是经验值，能覆盖绝大多数场景，同时避免卡死主线程太久。
# 显式传 timeout= 仍以用户值为准。
_DEFAULT_CMD_TIMEOUT_S = 30.0


class Planner:
    """轨迹规划 / TF 查询 / 路径点管理 统一客户端。

    内部管理三个 :class:`BaseZMQClient`（每个服务一个 DEALER socket）。
    任意一个不可用，构造时立即抛 :class:`ParmAPIError`（``error_code=2003``）。

    Args:
        host: 服务主机名 / IP。
        trajectory_port: 轨迹规划服务端口（默认 5604）。
        tf_port: TF 查询服务端口（默认 5609）。
        waypoint_port: 路径点管理服务端口（默认 5610）。
        cmd_init_timeout: 构造时端口可用性探测超时。
    """

    def __init__(
        self,
        host: str = "localhost",
        *,
        trajectory_port: int = DEFAULT_TRAJECTORY_PORT,
        tf_port: int = DEFAULT_TF_PORT,
        waypoint_port: int = DEFAULT_WAYPOINT_PORT,
        cmd_init_timeout: float = 2.0,
    ) -> None:
        for name, port in (
            ("trajectory", trajectory_port),
            ("tf", tf_port),
            ("waypoint", waypoint_port),
        ):
            if not BaseZMQClient.is_server_available(
                host, port, timeout=_SERVER_AVAILABLE_TIMEOUT_S
            ):
                raise ParmAPIError(
                    f"no server listening at tcp://{host}:{port} ({name})",
                    error_code=2003,
                )

        self._trajectory = BaseZMQClient(
            host=host, cmd_port=trajectory_port, status_port=None,
            cmd_init_timeout=cmd_init_timeout,
        )
        self._tf = BaseZMQClient(
            host=host, cmd_port=tf_port, status_port=None,
            cmd_init_timeout=cmd_init_timeout,
        )
        self._waypoint = BaseZMQClient(
            host=host, cmd_port=waypoint_port, status_port=None,
            cmd_init_timeout=cmd_init_timeout,
        )

    # ----- 公共接口：轨迹规划 -----

    def plan_trajectory(
        self,
        waypoints: list[dict[str, Any]],
        *,
        max_vel: float | None = None,
        max_acc: float | None = None,
        topp: "TOPPConfig | dict[str, Any] | None" = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """发送轨迹规划请求。

        Args:
            waypoints: 路点列表；每个路点 dict 详见 SDK 文档 §轨迹规划。
                内部会对每个路点做基础校验（``type`` / ``planner``）。
            max_vel: TOPP 最大速度比例（``None``=用默认 0.1）。与 ``max_acc``
                一起自动组成 :class:`TOPPConfig` 的 ``max_vel_factor`` /
                ``max_acc_factor``。``final_phase_*`` 字段用默认值。
            max_acc: TOPP 最大加速度比例（``None``=用默认 0.1）。
            topp: TOPP 时间参数化配置（高级）。三种形式：
                - :class:`TOPPConfig` 实例（**推荐**，字段类型校验）
                - ``dict``（wire 字面量向后兼容）
                - ``None``（不传，服务端用默认）

                注意：``topp`` 与 ``max_vel`` / ``max_acc`` 同时传时，``topp``
                **优先**（``max_vel`` / ``max_acc`` 忽略）。
            timeout: 命令超时秒数。默认 30s（``_DEFAULT_CMD_TIMEOUT_S``）。
                显式传 None 走 BaseZMQClient 默认 1s（**不建议**）。

        Returns:
            完整响应 envelope（含 ``success`` / ``message`` / ``data``）。
            ``data.arm_id``、``data.trajectory``、``data.sample_frequency``
            在成功时存在。
        """
        if not isinstance(waypoints, list) or not waypoints:
            raise ValueError("waypoints must be a non-empty list")
        for i, wp in enumerate(waypoints):
            self._validate_waypoint(wp, index=i)

        # 解析 topp：topp 显式传就优先；否则 max_vel/max_acc 组成；
        # 都没有则 None（服务端用默认）。
        if topp is not None:
            topp_payload = self._normalize_topp(topp)
        elif max_vel is not None or max_acc is not None:
            vel = max_vel if max_vel is not None else 0.1
            acc = max_acc if max_acc is not None else 0.1
            topp_payload = TOPPConfig(
                max_vel_factor=vel, max_acc_factor=acc,
            ).to_wire()
        else:
            topp_payload = None

        payload: dict[str, Any] = {"waypoints": waypoints}
        if topp_payload is not None:
            payload["topp"] = topp_payload

        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        response = self._trajectory.send_payload(payload, timeout=timeout)
        return response

    def plan_joint_trajectory(
        self,
        *,
        group: str,
        planner: str,
        joint_names: list[str],
        joint_values: list[float],
        max_vel: float = 0.1,
        max_acc: float = 0.1,
        topp: "TOPPConfig | dict[str, Any] | None" = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """关节空间轨迹规划快捷方法。

        ``max_vel`` / ``max_acc`` / ``topp`` / ``timeout`` 含义同
        :meth:`plan_trajectory`。``max_vel`` / ``max_acc`` 直接透传给
        :meth:`plan_trajectory` 内部组装 TOPP。
        """
        waypoint = self._build_joint_waypoint(
            name="temp_waypoint",
            group=group,
            planner=planner,
            joint_names=joint_names,
            joint_values=joint_values,
        )
        return self.plan_trajectory(
            [waypoint],
            max_vel=max_vel,
            max_acc=max_acc,
            topp=topp,
            timeout=timeout,
        )

    def plan_cart_trajectory(
        self,
        *,
        group: str,
        planner: str,
        frame_id: str,
        ik_frame: str,
        position: list[float],
        orientation: list[float],
        max_vel: float = 0.1,
        max_acc: float = 0.1,
        topp: "TOPPConfig | dict[str, Any] | None" = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """笛卡尔空间轨迹规划快捷方法。

        参数含义同 :meth:`plan_joint_trajectory`。
        """
        waypoint = self._build_cart_waypoint(
            name="temp_waypoint",
            group=group,
            planner=planner,
            frame_id=frame_id,
            ik_frame=ik_frame,
            position=position,
            orientation=orientation,
        )
        return self.plan_trajectory(
            [waypoint],
            max_vel=max_vel,
            max_acc=max_acc,
            topp=topp,
            timeout=timeout,
        )

    # ----- 公共接口：TF 查询 -----

    def get_all_frames(
        self,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """获取 TF 树中所有坐标系 ID。

        Returns:
            响应 envelope。``data.frame_ids`` 为坐标系名称列表。
        """
        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        response = self._tf.send_payload(
            {"action": "get_all_frames"}, timeout=timeout,
        )
        return response

    def list_frame_ids(self, *, timeout: float | None = None) -> list[str]:
        """``get_all_frames()`` 的快捷方法：直接返回 frame_ids 列表。"""
        response = self.get_all_frames(timeout=timeout)
        data = response.get("data") or {}
        return list(data.get("frame_ids") or [])

    def lookup_transform(
        self,
        source_frame: str,
        target_frame: str,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """查询 ``source_frame`` → ``target_frame`` 的坐标变换。

        Returns:
            响应 envelope。``data`` 含 ``source_frame`` / ``target_frame`` /
            ``timestamp``（``{sec, nanosec}``）/ ``translation``（``{x,y,z}``）/
            ``rotation``（四元数 ``{x,y,z,w}``）。
        """
        if not isinstance(source_frame, str) or not source_frame:
            raise ValueError("source_frame must be a non-empty string")
        if not isinstance(target_frame, str) or not target_frame:
            raise ValueError("target_frame must be a non-empty string")
        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        return self._tf.send_payload(
            {
                "action": "lookup_transform",
                "data": {
                    "source_frame": source_frame,
                    "target_frame": target_frame,
                },
            },
            timeout=timeout,
        )

    # ----- 公共接口：路径点管理 -----

    def list_waypoints(
        self,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """列出所有路径点。"""
        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        return self._waypoint.send_payload(
            {"action": "list"}, timeout=timeout,
        )

    def get_waypoint(
        self,
        *,
        name: str | None = None,
        id: str | None = None,  # noqa: A002 — 保留 wire 字段名
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """按 ``name`` 或 ``id`` 查单个路径点；都不传则返回全部。"""
        if name is None and id is None:
            if timeout is None:
                timeout = _DEFAULT_CMD_TIMEOUT_S
            return self._waypoint.send_payload(
                {"action": "get", "data": {}}, timeout=timeout,
            )
        data: dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if id is not None:
            data["id"] = id
        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        return self._waypoint.send_payload(
            {"action": "get", "data": data}, timeout=timeout,
        )

    def add_waypoint(
        self,
        *,
        name: str,
        type: str,  # noqa: A002
        group: str,
        planner: str,
        joint_names: list[str] | None = None,
        joint_values: list[float] | None = None,
        frame_id: str | None = None,
        ik_frame: str | None = None,
        position: list[float] | None = None,
        orientation: list[float] | None = None,
        max_velocity_scaling_factor: float = _DEFAULT_VEL_SCALE,
        max_acceleration_scaling_factor: float = _DEFAULT_ACC_SCALE,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """新增路径点。"""
        if not isinstance(name, str) or not name:
            raise ValueError("name must be a non-empty string")
        if type not in _WAYPOINT_TYPES:
            raise ValueError(f"type must be one of {_WAYPOINT_TYPES}, got {type!r}")

        wp = {
            "name": name,
            "type": type,
            "group": group,
            "planner": planner,
            "max_velocity_scaling_factor": max_velocity_scaling_factor,
            "max_acceleration_scaling_factor": max_acceleration_scaling_factor,
        }
        if type == "joint":
            wp["joint_names"] = list(joint_names or [])
            wp["joint_values"] = list(joint_values or [])
        else:
            wp["frame_id"] = frame_id
            wp["ik_frame"] = ik_frame
            wp["position"] = list(position or [])
            wp["orientation"] = list(orientation or [])

        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        return self._waypoint.send_payload(
            {"action": "add", "data": wp}, timeout=timeout,
        )

    def update_waypoint(
        self,
        *,
        name: str | None = None,
        id: str | None = None,  # noqa: A002
        fields: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """按 ``name`` 或 ``id`` 更新路径点；``fields`` 是要改的字段（不含 id/name）。"""
        if name is None and id is None:
            raise ValueError("either name or id must be provided")
        if not fields:
            raise ValueError("fields must be a non-empty dict")
        data: dict[str, Any] = dict(fields)
        if name is not None:
            data["name"] = name
        if id is not None:
            data["id"] = id
        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        return self._waypoint.send_payload(
            {"action": "update", "data": data}, timeout=timeout,
        )

    def delete_waypoint(
        self,
        *,
        name: str | None = None,
        id: str | None = None,  # noqa: A002
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """按 ``name`` 或 ``id`` 删除路径点。"""
        if name is None and id is None:
            raise ValueError("either name or id must be provided")
        data: dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if id is not None:
            data["id"] = id
        if timeout is None:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        return self._waypoint.send_payload(
            {"action": "delete", "data": data}, timeout=timeout,
        )

    # ----- 生命周期 -----

    def close(self) -> None:
        for client in (self._trajectory, self._tf, self._waypoint):
            try:
                client.close()
            except Exception:  # noqa: BLE001 — best-effort close
                pass

    def __enter__(self) -> "Planner":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ----- 私有辅助 -----

    @staticmethod
    def _normalize_topp(topp: "TOPPConfig | dict[str, Any]") -> dict[str, Any]:
        """统一 TOPP 参数为 wire dict。

        - :class:`TOPPConfig` → 直接 ``to_wire()``
        - ``dict`` → 原样透传（让高级用户手填 wire 字段，零校验）
        """
        if isinstance(topp, TOPPConfig):
            return topp.to_wire()
        if isinstance(topp, dict):
            return dict(topp)
        raise TypeError(
            f"topp must be TOPPConfig or dict, got {type(topp).__name__}"
        )

    @staticmethod
    def _build_joint_waypoint(
        *,
        name: str,
        group: str,
        planner: str,
        joint_names: list[str],
        joint_values: list[float],
    ) -> dict[str, Any]:
        if planner not in _JOINT_PLANNERS:
            raise ValueError(
                f"planner must be one of {_JOINT_PLANNERS}, got {planner!r}"
            )
        if not isinstance(joint_names, list) or not joint_names:
            raise ValueError("joint_names must be a non-empty list")
        if not isinstance(joint_values, list) or not joint_values:
            raise ValueError("joint_values must be a non-empty list")
        if len(joint_names) != len(joint_values):
            raise ValueError(
                f"joint_names ({len(joint_names)}) and joint_values "
                f"({len(joint_values)}) must have equal length"
            )
        return {
            "name": name,
            "type": "joint",
            "group": group,
            "planner": planner,
            "max_velocity_scaling_factor": _DEFAULT_VEL_SCALE,
            "max_acceleration_scaling_factor": _DEFAULT_ACC_SCALE,
            "joint_names": list(joint_names),
            "joint_values": list(joint_values),
        }

    @staticmethod
    def _build_cart_waypoint(
        *,
        name: str,
        group: str,
        planner: str,
        frame_id: str,
        ik_frame: str,
        position: list[float],
        orientation: list[float],
    ) -> dict[str, Any]:
        if planner not in _CART_PLANNERS:
            raise ValueError(
                f"planner must be one of {_CART_PLANNERS}, got {planner!r}"
            )
        if not isinstance(position, list) or len(position) != 3:
            raise ValueError("position must be [x, y, z]")
        if not isinstance(orientation, list) or len(orientation) != 4:
            raise ValueError("orientation must be [x, y, z, w] quaternion")
        return {
            "name": name,
            "type": "cart",
            "group": group,
            "planner": planner,
            "max_velocity_scaling_factor": _DEFAULT_VEL_SCALE,
            "max_acceleration_scaling_factor": _DEFAULT_ACC_SCALE,
            "frame_id": frame_id,
            "ik_frame": ik_frame,
            "position": list(position),
            "orientation": list(orientation),
        }

    @staticmethod
    def _validate_waypoint(wp: Any, *, index: int) -> None:
        if not isinstance(wp, dict):
            raise ValueError(f"waypoints[{index}] must be a dict, got {type(wp).__name__}")
        wp_type = wp.get("type")
        if wp_type not in _WAYPOINT_TYPES:
            raise ValueError(
                f"waypoints[{index}].type must be one of {_WAYPOINT_TYPES}, got {wp_type!r}"
            )
        planner = wp.get("planner")
        valid = _JOINT_PLANNERS if wp_type == "joint" else _CART_PLANNERS
        if planner not in valid:
            raise ValueError(
                f"waypoints[{index}].planner must be one of {valid}, got {planner!r}"
            )


__all__ = ["Planner"]