"""Relay（继电器）高级 API。

控制两路继电器的开关，支持脉冲模式（``pulse_ms``）。

C++ 服务端使用 ZMQ ROUTER 暴露命令通道（默认端口 ``7707``），客户端用
DEALER 连接、identity 固定为 ``b"relay"``（约定值，服务端接受任意非空
identity）。无状态 PUB 端口 —— 命令是 fire-and-await，单次 DEALER 往返即可。

Wire 形态::

    request:  {"cmd": "set", "r1": int|None, "r2": int|None,
               "pulse_ms": int|None}
    response: {"success": true|false, "message": "..."}

``r1`` / ``r2`` 状态值：
    - ``0``  关闭
    - ``1``  打开
    - ``2``  保持不变

未提供的通道保持不变。``pulse_ms`` 仅与至少一个值为 ``1`` 的通道同时使用
有效；大于 0 时服务端在指定毫秒后自动关闭本次打开的通道。

``send_payload`` 已统一处理 ``success=false`` 响应 → ``ParmAPIError``，
所以 ``set()`` 直接返回完整 envelope dict（``success`` / ``message``）。

接线翻转约定
------------

SDK 层 ``r1`` 抽象为"左手"（与 Arm.arm_id 1=左 一致），``r2`` 为"右手"。
但物理接线可与该约定不一致：当前部署里**电磁铁接反了**（wire r1 接右手、
wire r2 接左手）。``Relay()`` 默认配置按该部署设置，构造 kwargs
``gripper_left_device="r2"`` / ``gripper_right_device="r1"`` 把 SDK 抽象
映射到物理通道。

未来如果改正接线，传 ``Relay(gripper_left_device="r1", gripper_right_device="r2")``
即可。

便捷接口
--------

- :meth:`set_channels(left, right, pulse_seconds)` —— 语义化接口，按
  "左手/右手"调用（自动应用上面翻转）。
- :meth:`pulse(channel, seconds)` —— 5 秒脉冲便捷方法（电磁铁长时间通电
  会烧，调脉冲更安全）。
"""

from __future__ import annotations

import logging
from typing import Any

from parm_sdk.api.exceptions import ParmAPIError
from parm_sdk.sdk.transport import BaseZMQClient

_LOGGER = logging.getLogger("parm_sdk.sdk.relay")

_SERVER_AVAILABLE_TIMEOUT_S = 0.1

# 默认端口 + identity（与 force_sensor 同协议族，identity "force" / "relay"
# 是文档约定的客户端名字）。
_DEFAULT_CMD_PORT = 7707
_DEFAULT_IDENTITY = b"relay"

# 状态值：0=关闭、1=打开、2=保持不变。
_VALID_STATES = (0, 1, 2)

# pulse_ms 上限（int32 上界，按 wire 协议约定）。
_MAX_PULSE_MS = 2147483647

# SDK 层手索引（与 Arm.arm_id / Gripper.hand_name 约定一致）。
_HAND_1 = 1  # 左手
_HAND_2 = 2  # 右手

# 默认物理 wire 映射：左手 → wire "r2"，右手 → wire "r1"（适配当前电磁铁
# 接反的部署）。构造 kwargs ``gripper_left_device`` / ``gripper_right_device``
# 可覆盖。
_DEFAULT_LEFT_DEVICE = "r2"
_DEFAULT_RIGHT_DEVICE = "r1"


class Relay:
    """两路继电器控制 API。

    SDK 抽象约定：``r1``=左手、``r2``=右手（与 Arm.arm_id 一致）。
    物理 wire 通道由构造 kwargs ``gripper_left_device`` / ``gripper_right_device``
    决定，默认按当前部署的接反接线设置。
    """

    def __init__(
        self,
        host: str = "localhost",
        cmd_port: int = _DEFAULT_CMD_PORT,
        cmd_init_timeout: float = 2.0,
        *,
        identity: bytes = _DEFAULT_IDENTITY,
        req_timeout_ms: int = 1000,
        gripper_left_device: str = _DEFAULT_LEFT_DEVICE,
        gripper_right_device: str = _DEFAULT_RIGHT_DEVICE,
    ) -> None:
        if not BaseZMQClient.is_server_available(
            host, cmd_port, timeout=_SERVER_AVAILABLE_TIMEOUT_S
        ):
            raise ParmAPIError(
                f"no server listening at tcp://{host}:{cmd_port}",
                error_code=2003,
            )

        self._gripper_left_device = gripper_left_device
        self._gripper_right_device = gripper_right_device
        self._client = BaseZMQClient(
            host=host,
            cmd_port=cmd_port,
            status_port=None,  # 继电器无 PUB 通道
            identity=identity,
            req_timeout_ms=req_timeout_ms,
            cmd_init_timeout=cmd_init_timeout,
        )

    # —— 公共接口 ——

    def set(
        self,
        r1: int | None = None,
        r2: int | None = None,
        pulse_ms: int | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """设置继电器状态（按 SDK 抽象 r1=左手、r2=右手）。

        Args:
            r1: 左手状态（``0``=关闭 / ``1``=打开 / ``2``=保持不变）。
                ``None``=不修改。SDK 抽象 r1 → 物理 wire 由
                ``gripper_left_device`` 决定。
            r2: 右手状态。``None``=不修改。
            pulse_ms: 脉冲持续毫秒数（``>= 0``）。``None`` 或 ``0`` 表示
                普通（非脉冲）模式。**仅与至少一个值为 ``1`` 的通道同时使用
                有效**。
            timeout: 命令超时秒数；``None``=使用构造时的 ``req_timeout_ms``。
                **带脉冲时请显式或用 :meth:`pulse`**（其内部按脉冲时长自动
                计算超时），否则 1s 默认值会立刻撞超时。

        Returns:
            响应 envelope dict，键集 ``{"success", "message"}``：
            ``success=True`` 表示设备应答校验通过；``success=False`` 已被
            :class:`BaseZMQClient.send_payload` 转成 ``ParmAPIError``。

        Raises:
            ValueError: ``r1`` / ``r2`` / ``pulse_ms`` 类型或范围非法，
                或 ``pulse_ms`` 与全非 1 通道组合。
            ParmAPIError: 服务端返回 ``success=false``、超时、socket 错误。
        """
        if r1 is None and r2 is None:
            raise ValueError("at least one of r1 / r2 must be provided")
        self._validate_state("r1", r1)
        self._validate_state("r2", r2)
        self._validate_pulse_ms(pulse_ms, r1=r1, r2=r2)

        # 带脉冲时，如未显式给 timeout，自动按脉冲时长 + 1s buffer 算，
        # 避免 1s 默认值撞超时（参见 pulse() 方法）。
        if timeout is None and pulse_ms is not None and pulse_ms > 0:
            timeout = pulse_ms / 1000.0 + 1.0

        payload: dict[str, Any] = {"cmd": "set"}
        if r1 is not None:
            payload[self._gripper_left_device] = r1
        if r2 is not None:
            payload[self._gripper_right_device] = r2
        if pulse_ms is not None and pulse_ms > 0:
            payload["pulse_ms"] = pulse_ms

        return self._client.send_payload(payload, timeout=timeout)

    def set_channels(
        self,
        left: int | None = None,
        right: int | None = None,
        pulse_seconds: float | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """语义化接口：``left`` / ``right`` 直接对应左手/右手。

        等价于 :meth:`set(r1=left, r2=right, pulse_ms=pulse_seconds*1000)`。
        """
        pulse_ms = (
            int(round(pulse_seconds * 1000))
            if pulse_seconds is not None and pulse_seconds > 0
            else None
        )
        return self.set(
            r1=left,
            r2=right,
            pulse_ms=pulse_ms,
            timeout=timeout,
        )

    def pulse(
        self,
        channel: int,
        seconds: float = 5.0,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """单通道脉冲：打开指定手通道 ``seconds`` 秒后自动关闭。

        电磁铁长时间通电会过热，本方法是常用便捷接口。

        Args:
            channel: 手索引（与 Arm.arm_id / Gripper.hand_name 约定一致）：
                ``1``=左手、``2``=右手。
            seconds: 持续秒数，默认 5.0。
            timeout: 命令超时秒数。``None`` 时按脉冲时长自动设：
                ``pulse_ms + 1s buffer``（保证服务端能等到脉冲结束再返回）。

        Raises:
            ValueError: ``channel`` 不是 1 或 2；``seconds`` 越界。
        """
        if isinstance(channel, bool) or not isinstance(channel, int):
            raise ValueError(f"channel must be int (1 or 2), got {type(channel).__name__}")
        if channel not in (_HAND_1, _HAND_2):
            raise ValueError(f"channel must be 1 or 2, got {channel!r}")
        if not isinstance(seconds, (int, float)) or isinstance(seconds, bool):
            raise ValueError(f"seconds must be a number, got {type(seconds).__name__}")
        if seconds < 0 or seconds > _MAX_PULSE_MS / 1000:
            raise ValueError(f"seconds must be in [0, {_MAX_PULSE_MS / 1000}], got {seconds}")
        pulse_ms = int(round(seconds * 1000)) if seconds > 0 else None

        # 用户没显式传 timeout 时，自动按脉冲时长 + 1s buffer 算。
        # 服务端会在脉冲结束 + 设备应答后才返回 success；如用默认
        # 1s 超时会立刻撞 "timeout waiting for response"。
        if timeout is None and pulse_ms is not None:
            timeout = pulse_ms / 1000.0 + 1.0

        # channel 1 → SDK r1（左手）；channel 2 → SDK r2（右手）。
        # wire 层的物理翻转由 set() 内部的 gripper_left_device / right_device
        # kwargs 自动处理（默认配置适配当前接反部署）。
        if channel == _HAND_1:
            return self.set(
                r1=1,
                pulse_ms=pulse_ms,
                timeout=timeout,
            )
        return self.set(
            r2=1,
            pulse_ms=pulse_ms,
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "Relay":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # —— 私有辅助 ——

    @staticmethod
    def _validate_state(name: str, value: int | None) -> None:
        if value is None:
            return
        if not isinstance(value, int) or isinstance(value, bool):
            raise ValueError(
                f"{name} must be int, got {type(value).__name__}"
            )
        if value not in _VALID_STATES:
            raise ValueError(
                f"{name} must be one of {_VALID_STATES}, got {value}"
            )

    @staticmethod
    def _validate_pulse_ms(
        pulse_ms: int | None,
        *,
        r1: int | None,
        r2: int | None,
    ) -> None:
        if pulse_ms is None:
            return
        if not isinstance(pulse_ms, int) or isinstance(pulse_ms, bool):
            raise ValueError(
                f"pulse_ms must be int, got {type(pulse_ms).__name__}"
            )
        if pulse_ms < 0 or pulse_ms > _MAX_PULSE_MS:
            raise ValueError(
                f"pulse_ms must be in [0, {_MAX_PULSE_MS}], got {pulse_ms}"
            )
        # pulse_ms 仅与至少一个值为 1 的通道同时使用。
        if r1 != 1 and r2 != 1:
            raise ValueError(
                "pulse_ms is only valid when at least one of r1/r2 is 1 (open)"
            )


__all__ = ["Relay"]