"""机械臂（Arm）高级 API。"""

from __future__ import annotations

import copy
import logging
from typing import Any

from parm_sdk.api.arm.commands import ArmCommand
from parm_sdk.api.exceptions import ParmAPIError
from parm_sdk.sdk.transport import BaseZMQClient

_LOGGER = logging.getLogger("parm_sdk.sdk.arm")

_SERVER_AVAILABLE_TIMEOUT_S = 0.1
_VALID_ARM_IDS = (0, 1, 2)
_SINGLE_ARM_IDS = (1, 2)

# 各命令推荐超时。同步 motion 类命令要等服务端真正到达终态（含硬件执行）
# 默认 30s 在 move_j 实跑 3s 这种场景下也会太紧；显式按档给够。
# 慢速档（move_j / move_l / follow_trajectory）放宽到 300s 是因为实际部署
# 中会遇到重负载 / 多关节同时到位 / 长轨迹，120s 也不够用；放宽到 300s 兜底。
_DEFAULT_CMD_TIMEOUT_S = 30.0    # 通用（enable / disable / cancel / record / teach 等）
_MOTION_TIMEOUT_S = 300.0       # move_j / move_l，等待硬件到达 joint 终态
_TRAJECTORY_TIMEOUT_S = 300.0   # follow_trajectory，几十 ~ 几百点
_SERVO_START_TIMEOUT_S = 10.0   # start_servo_pose / start_servo_j，只需等服务 accept

# 命令 → 推荐的 SDK 端 RCVTIMEO 副本（详见 _send）。
_MOTION_CMDS: frozenset[str] = frozenset({
    ArmCommand.MOVE_J.value,
    ArmCommand.MOVE_L.value,
})
_TRAJECTORY_CMDS: frozenset[str] = frozenset({
    ArmCommand.EXECUTE_TRAJECTORY.value,
})
_SERVO_START_CMDS: frozenset[str] = frozenset({
    ArmCommand.SERVO_J.value,
    ArmCommand.SERVO_L.value,
    ArmCommand.START_SERVO_POSE.value,
    ArmCommand.STOP_SERVO_POSE.value,
    ArmCommand.SERVO_POSE.value,
})

# ``get_state()`` 返回 frame 的顶层白名单。``state`` 子层（per-arm）原样保留，
# 仅剔除非信息字段 ``arm_names``（冗余 = ``state.keys()``）与
# ``base_transforms``（系统配置，运行期不变）。
_ARM_FRAME_KEEP_KEYS: tuple[str, ...] = (
    "timestamp",
    "system_state",
    "estop_reason",
    "state",
)


class Arm:
    """机械臂同步 API。"""

    def __init__(
        self,
        host: str = "localhost",
        cmd_port: int = 5600,
        status_port: int = 5601,
        topic_prefix: str = "parm_driver.state",
        cmd_init_timeout: float = 2.0,
    ) -> None:
        if not BaseZMQClient.is_server_available(
            host, cmd_port, timeout=_SERVER_AVAILABLE_TIMEOUT_S
        ):
            raise ParmAPIError(
                f"no server listening at tcp://{host}:{cmd_port}",
                error_code=2003,
            )
        self._client = BaseZMQClient(
            host=host,
            cmd_port=cmd_port,
            status_port=status_port,
            topic_prefix=topic_prefix,
            cmd_init_timeout=cmd_init_timeout,
        )

    def get_state(self) -> dict | None:
        frame = self._client.get_state()
        return _filter_arm_state(frame)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "Arm":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def _check_server_available(self) -> None:
        if not BaseZMQClient.is_server_available(
            self._client._host, self._client._cmd_port,
            timeout=_SERVER_AVAILABLE_TIMEOUT_S,
        ):
            raise ParmAPIError(
                f"server at tcp://{self._client._host}:{self._client._cmd_port} unavailable",
                error_code=2003,
            )

    def _send(self, cmd: str, args: dict[str, Any] | None = None) -> dict | None:
        """按命令类型选择 RCVTIMEO。

        早先版本不传 timeout，导致 socket 用构造时的 100ms 默认值
        （``req_timeout_ms=1000`` 是秒 = 1s，但 RCVTIMEO 是 1s 单位不对）。
        实际是 ``BaseZMQClient.__init__`` 里 ``req_timeout_ms=1000`` 直接写
        ``setsockopt(int(req_timeout_ms))`` ms = 1000ms，又因为 send_payload
        在 ``timeout=None`` 时跳过 setsockopt，socket 一直停留在 1000ms / 1s。
        move_j 实跑 3s 时必中招。本函数按命令分档设 timeout。

        各档阈值见模块顶部的常量；调用方也可显式 ``timeout=`` 覆盖。
        当前默认档：move_j/move_l/follow_trajectory 走 300s 长档，其它命令 30s，
        servo start 类 10s。
        """
        self._check_server_available()
        if cmd in _TRAJECTORY_CMDS:
            timeout = _TRAJECTORY_TIMEOUT_S
        elif cmd in _MOTION_CMDS:
            timeout = _MOTION_TIMEOUT_S
        elif cmd in _SERVO_START_CMDS:
            timeout = _SERVO_START_TIMEOUT_S
        else:
            timeout = _DEFAULT_CMD_TIMEOUT_S
        return self._client.send_command(cmd, args or {}, timeout=timeout)

    def _validate_arm_id(self, arm_id: int, allow_zero: bool = True) -> None:
        valid = _VALID_ARM_IDS if allow_zero else _SINGLE_ARM_IDS
        if arm_id not in valid:
            raise ValueError(f"arm_id must be one of {valid}, got {arm_id}")

    # —— 基础 ——
    def enable(self) -> None:
        self._send(ArmCommand.ENABLE.value)

    def disable(self) -> None:
        self._send(ArmCommand.DISABLE.value)

    # —— 运动 ——
    def move_j(self, arm_id: int, positions: list[float], speed: float = 0.5) -> None:
        self._validate_arm_id(arm_id)
        if not isinstance(positions, list) or not positions:
            raise ValueError("positions must be a non-empty list")
        if arm_id == 0 and len(positions) != 14:
            raise ValueError("dual-arm move_j requires 14 joint positions")
        if arm_id in _SINGLE_ARM_IDS and len(positions) != 7:
            raise ValueError(f"single-arm move_j requires 7 joint positions, got {len(positions)}")
        if not (0.0 <= speed <= 1.0):
            raise ValueError(f"speed must be in [0, 1], got {speed}")
        self._send(ArmCommand.MOVE_J.value, {
            "arm_id": arm_id, "positions": positions, "speed": speed,
        })

    def move_l(self, *args, **kwargs) -> None:
        raise NotImplementedError("move_l is not yet implemented")

    def follow_trajectory(
        self, arm_id: int, trajectory: list[list[float]], sample_frequency: float = 10.0,
    ) -> None:
        """按轨迹路点序列执行一条**连续**的关节运动。

        与"循环多次 ``move_j``"的关键区别：**整条轨迹是单条连续运动**——
        服务端在所有路点上做一次全局轨迹优化，相邻路点之间不停顿、不重新
        规划、不重新加减速，机械臂以平滑的速度曲线过完每个路点。``move_j``
        则是每次"加到目标 → 停下 → 重新规划下一段"，离散点之间有明显停顿。

        服务端在路点之间按 ``sample_frequency`` 插补下发控制点；相邻路点
        越密越平滑，越疏越粗。

        Args:
            arm_id: 目标机械臂（`0`=双臂，`1`=左，`2`=右）。
            trajectory: 关节路点序列；单臂每点 7 个角度（**度**），双臂
                每点 14 个。路点非空，长度任意。
            sample_frequency: 相邻路点之间的插补下发频率（Hz），默认
                10.0；越大越平滑，对路点密度要求越高。

        Returns:
            None（**阻塞**返回）：到达最后一个路点（或出错 / 超时）才返回。

        Note:
            - 默认超时 300s；可手动 ``timeout=`` 覆盖
            - 如需中断：`cancel_task(arm_id)`
            - 录制回放时建议把 ``sample_frequency`` 与录制时一致
        """
        self._validate_arm_id(arm_id)
        if not trajectory:
            raise ValueError("trajectory must not be empty")
        if sample_frequency <= 0:
            raise ValueError("sample_frequency must be > 0")
        self._send(ArmCommand.EXECUTE_TRAJECTORY.value, {
            "arm_id": arm_id, "trajectory": trajectory, "sample_frequency": sample_frequency,
        })

    def cancel_task(self, arm_id: int = 0) -> None:
        self._validate_arm_id(arm_id)
        self._send(ArmCommand.CANCEL_TASK.value, {"arm_id": arm_id})

    # —— 安全 ——
    def clear_error(self) -> None:
        """从 ``ERROR`` 状态确认并恢复。

        服务端在硬件异常（速度 / 加速度超限 / 任务中失使能等）下会进入
        ``ERROR`` 状态并拒绝所有运动命令。与 ``release_estop`` 对称：
        ``release_estop`` 解 ``ESTOP``、``clear_error`` 解 ``ERROR``，
        必须**由用户显式确认**才会清除故障（不会自动恢复）。

        调用后系统从 ``ERROR`` -> ``BOOTING``，再由 watchdog 转 ``RUNNING``。

        Raises:
            ParmAPIError: 当前不在 ``ERROR`` 状态 / ``ESTOP`` 状态优先调
                ``release_estop``、硬件故障未清除等。
        """
        self._send(ArmCommand.CONFIRM_RECOVERY.value, {})

    # —— Servo ——
    def servo_j(self, arm_id: int, positions: list[float]) -> None:
        self._validate_arm_id(arm_id, allow_zero=False)
        if not isinstance(positions, list) or len(positions) != 7:
            raise ValueError("servo_j requires 7 joint positions")
        self._send(ArmCommand.SERVO_J.value, {
            "arm_id": arm_id, "positions": positions,
        })

    def servo_l(
        self, arm_id: int, delta: list[float],
        tcp: list[float] | None = None, frame: str = "world",
    ) -> None:
        self._validate_arm_id(arm_id, allow_zero=False)
        if not isinstance(delta, list) or len(delta) != 6:
            raise ValueError("servo_l delta must be a 6-element list")
        if frame not in ("world", "tcp"):
            raise ValueError("frame must be 'world' or 'tcp'")
        self._send(ArmCommand.SERVO_L.value, {
            "arm_id": arm_id, "delta": delta,
            "tcp": tcp or [0.0] * 6, "frame": frame,
        })

    def start_servo_pose(
        self, arm_id: int, pose_type: str, frame: str,
        tcp: list[float], input_frequency_hz: float = 25.0,
    ) -> None:
        self._validate_arm_id(arm_id, allow_zero=False)
        if pose_type not in ("absolute", "delta"):
            raise ValueError("pose_type must be 'absolute' or 'delta'")
        if frame not in ("world", "base", "tcp"):
            raise ValueError("frame must be 'world', 'base', or 'tcp'")
        if not isinstance(tcp, list) or len(tcp) != 6:
            raise ValueError("tcp must be a 6-element list")
        if input_frequency_hz <= 0:
            raise ValueError("input_frequency_hz must be > 0")
        self._send(ArmCommand.START_SERVO_POSE.value, {
            "arm_id": arm_id, "pose_type": pose_type, "frame": frame,
            "tcp": tcp, "input_frequency_hz": input_frequency_hz,
        })

    def push_servo_pose(self, arm_id: int, target: list[float]) -> None:
        self._validate_arm_id(arm_id, allow_zero=False)
        if not isinstance(target, list) or len(target) != 6:
            raise ValueError("target must be a 6-element list")
        self._send(ArmCommand.SERVO_POSE.value, {
            "arm_id": arm_id, "target": target,
        })

    def stop_servo_pose(self, arm_id: int) -> None:
        self._validate_arm_id(arm_id, allow_zero=False)
        self._send(ArmCommand.STOP_SERVO_POSE.value, {"arm_id": arm_id})

    # —— 示教 ——
    def start_admittance_teach(self, arm_id: int) -> None:
        self._validate_arm_id(arm_id)
        self._send(ArmCommand.START_ADMITTANCE_TEACH.value, {"arm_id": arm_id})

    def stop_admittance_teach(self, arm_id: int) -> None:
        self._validate_arm_id(arm_id)
        self._send(ArmCommand.STOP_ADMITTANCE_TEACH.value, {"arm_id": arm_id})

    def start_teach(self, arm_id: int, *, free: bool = False) -> None:
        """启动电流伺服示教。

        Args:
            arm_id: 目标机械臂（1=左、2=右；双臂协同 0 不支持示教）。
            free: ``False``（默认）= 拖动示教：机械臂 STATIC ↔ MOVING 自动
                切换，基于扭矩阈值识别外力。``True`` = Free 模式：机械臂
                期望进入永久 MOVING（"失重"），**仅** ``stop_teach`` /
                ``cancel_task`` 可退出。

        Note:
            **2026-07 变更** —— Free 模式不再要求启动时处于 home 位置。
            启动后是否真正进入电流模式由独立的 ``parm_activate_teach`` 服务
            门控：服务端 20Hz 订阅其 PUB 信号，连续 10 帧包含该臂的
            ``active_arms`` → 任务从 STATIC 切到 MOVING 并下发前馈电流；
            200ms 内没收到信号 → 自动回 STATIC（暂停而非终止，重新激活即可
            继续）。详见 ``docs/zmq_docs/arm.md`` §2.5。
        """
        self._validate_arm_id(arm_id)
        if not isinstance(free, bool):
            raise ValueError(f"free must be a bool, got {type(free).__name__}")
        self._send(
            ArmCommand.START_TEACH.value,
            {"arm_id": arm_id, "free": free},
        )

    def stop_teach(self, arm_id: int) -> None:
        self._validate_arm_id(arm_id)
        self._send(ArmCommand.STOP_TEACH.value, {"arm_id": arm_id})

    # —— 录制 ——
    def start_record(self, arm_id: int, filename: str = "record") -> None:
        self._validate_arm_id(arm_id)
        if not isinstance(filename, str) or not filename:
            raise ValueError("filename must be a non-empty string")
        self._send(ArmCommand.START_RECORD.value, {
            "arm_id": arm_id, "filename": filename,
        })

    def stop_record(self, arm_id: int) -> None:
        self._validate_arm_id(arm_id)
        self._send(ArmCommand.STOP_RECORD.value, {"arm_id": arm_id})


__all__ = ["Arm"]


def _filter_arm_state(frame: dict[str, Any] | None) -> dict[str, Any] | None:
    """按白名单过滤 Arm 服务端 PUB 帧。

    保留 ``timestamp`` / ``system_state`` / ``estop_reason`` / ``state`` 四项；
    ``state.{arm}`` 子层（per-arm 状态）原样透传。剔除：

    - ``arm_names``：等同于 ``state.keys()``，冗余。
    - ``base_transforms``：运行期不变的系统配置。

    服务端缺字段时静默忽略（不抛错），仅返回白名单内存在的字段。
    ``frame`` 为 ``None`` 时原样返回 ``None``（客户端未就绪）。
    """
    if frame is None:
        return None
    return {k: copy.deepcopy(frame[k]) for k in _ARM_FRAME_KEEP_KEYS if k in frame}
