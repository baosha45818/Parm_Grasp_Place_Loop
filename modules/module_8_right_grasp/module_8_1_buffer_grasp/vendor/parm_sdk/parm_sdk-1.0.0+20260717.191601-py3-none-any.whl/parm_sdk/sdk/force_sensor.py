"""ForceSensor（力传感器）高级 API。

C++ 服务端**无 REQ/REP 命令通道**，仅通过 PUB 在端口 7703 / 7704 广播每帧 JSON
力/力矩数据（左手 7703、右手 7704）。SDK 仅做状态订阅，不发送命令。

实现说明：
- 不复用 ``_StateSubscriber``（M1 已有），后者要求非空 topic 前缀。
  ForceSensor C++ 侧使用 ``setsockopt(SUBSCRIBE, "")``（空 topic = 全匹配），
  为了不触碰稳定的 M1 代码，本模块自带一个最小 inline subscriber：
  ``_ForceSensorSubscriber``。
- inline subscriber 提供与 ``_StateSubscriber`` 等价的语义：
  - 后台线程持续 recv
  - CONFLATE=1 + RCVHWM=1，只保留最新帧
  - ``get_latest()`` 超过 0.5s 无新帧返回 None
  - ``wait_first(timeout)`` 阻塞等首帧
- 0.5s 过期阈值与 transport.py ``_STATUS_STALENESS_S`` 保持一致。
"""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Any

import zmq

_LOGGER = logging.getLogger("parm_sdk.sdk.force_sensor")

# 状态帧新鲜度阈值（秒）。超过此时间无新帧视为过期。
# 与 transport.py ``_STATUS_STALENESS_S`` 保持一致。
_STATUS_STALENESS_S = 0.5

# 状态订阅循环的 RCVTIMEO（毫秒）。
_SUB_RCVTIMEO_MS = 100

# 手 → PUB 端口映射（与 Arm.arm_id、Gripper.hand_name 约定一致：1=左、2=右）。
_HAND_PORTS: dict[int, int] = {1: 7703, 2: 7704}


class _ForceSensorSubscriber:
    """最小 inline PUB 订阅器，与 ``_StateSubscriber`` 等价但支持空 topic。

    帧协议：单帧 UTF-8 JSON（无 topic 前缀）。
    """

    def __init__(
        self,
        ctx: zmq.Context,
        host: str,
        port: int,
        wait_timeout: float,
    ) -> None:
        self._socket = ctx.socket(zmq.SUB)
        self._socket.setsockopt(zmq.CONFLATE, 1)
        self._socket.setsockopt(zmq.RCVHWM, 1)
        self._socket.setsockopt(zmq.RCVTIMEO, _SUB_RCVTIMEO_MS)
        self._socket.setsockopt(zmq.SUBSCRIBE, b"")
        self._socket.connect(f"tcp://{host}:{port}")

        self._wait_timeout = wait_timeout
        self._cache: dict | None = None
        self._last_seen_monotonic: float | None = None
        self._lock = threading.Lock()
        self._first_frame_event = threading.Event()

        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

        if not self._first_frame_event.wait(timeout=wait_timeout):
            self.stop()
            raise TimeoutError(
                f"timeout waiting for first frame on tcp://{host}:{port}"
            )

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                raw = self._socket.recv()
            except zmq.Again:
                continue
            except zmq.ZMQError:
                return
            try:
                data = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            with self._lock:
                self._cache = data
                self._last_seen_monotonic = time.monotonic()
                self._first_frame_event.set()

    def get_latest(self) -> dict | None:
        with self._lock:
            if self._last_seen_monotonic is None:
                return None
            if time.monotonic() - self._last_seen_monotonic > _STATUS_STALENESS_S:
                return None
            return dict(self._cache)

    def wait_first(self, timeout: float) -> dict:
        if self._first_frame_event.wait(timeout=timeout):
            with self._lock:
                return dict(self._cache)
        raise TimeoutError("timeout waiting for first frame")

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=2)
        try:
            self._socket.close(linger=0)
        except zmq.ZMQError:
            pass

    def close(self) -> None:
        """``stop()`` 的别名——ForceSensor 通过 ``_client.close()`` 委托关闭。"""
        self.stop()


class ForceSensor:
    """力传感器订阅 API。

    构造时启动后台 subscriber 线程，订阅 ``tcp://host:pub_port`` 上的
    PUB 帧。``read()`` 返回最新一帧 dict（含 ``filtered_force`` /
    ``filtered_torque`` / ``timestamp``）；None 表示未就绪或已过期。

    C++ 侧没有 REQ/REP 命令通道，故本类无 ``send_*`` 方法。

    左右手区分通过 ``hand`` 参数指定（``1``=左 PUB 7703 / ``2``=右 PUB 7704），
    与 Arm.arm_id、Gripper.hand_name 约定一致。需要自定义端口时传
    ``pub_port`` 显式覆盖（默认 ``None``=按 hand 自动选择）。
    """

    def __init__(
        self,
        host: str = "localhost",
        pub_port: int | None = None,
        pub_init_timeout: float = 2.0,
        hand: int = 1,
    ) -> None:
        if isinstance(hand, bool) or not isinstance(hand, int) or hand not in _HAND_PORTS:
            raise ValueError(
                f"hand must be one of {list(_HAND_PORTS)}, got {hand!r}"
            )
        if pub_port is None:
            pub_port = _HAND_PORTS[hand]
        self._hand = hand
        # ForceSensor 没有 cmd 通道；唯一外部依赖是 PUB 端口可达。
        # 我们不探测端口（"探测"语义对 PUB 不准），直接启动 subscriber，
        # 让 ``wait_first`` 在 ``pub_init_timeout`` 内抛出 TimeoutError。
        ctx = zmq.Context.instance()
        self._subscriber = _ForceSensorSubscriber(
            ctx=ctx,
            host=host,
            port=pub_port,
            wait_timeout=pub_init_timeout,
        )
        # 暴露给 conftest fixture：close() 委托给 _client.close()（对齐 Gripper 风格）。
        self._client = self._subscriber

    @property
    def hand(self) -> int:
        """返回当前实例订阅的力传感器手索引（``1`` 或 ``2``）。"""
        return self._hand

    # —— 公共接口 ——

    def get_state(self) -> dict | None:
        """返回最新一帧 dict。None 表示未就绪或已过期。"""
        if self._subscriber is None:
            return None
        return self._subscriber.get_latest()

    def read_force(self) -> list[float] | None:
        """便捷方法：返回 ``[fx, fy, fz]``，None 同 ``get_state()``。"""
        frame = self.get_state()
        if frame is None:
            return None
        return list(frame.get("filtered_force", []))

    def read_torque(self) -> list[float] | None:
        """便捷方法：返回 ``[mx, my, mz]``，None 同 ``get_state()``。"""
        frame = self.get_state()
        if frame is None:
            return None
        return list(frame.get("filtered_torque", []))

    def wait_first(self, timeout: float = 2.0) -> dict[str, Any]:
        """阻塞等到下一帧（一般用于测试或首次同步等待）。"""
        return self._subscriber.wait_first(timeout)

    def close(self) -> None:
        """关闭 subscriber。幂等。"""
        if getattr(self, '_closed', False):
            return
        self._closed = True
        if getattr(self, '_client', None) is not None:
            self._client.close()

    def __enter__(self) -> "ForceSensor":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


__all__ = ["ForceSensor"]