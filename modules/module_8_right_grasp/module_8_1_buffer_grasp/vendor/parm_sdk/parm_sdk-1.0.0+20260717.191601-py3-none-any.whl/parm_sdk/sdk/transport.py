"""ZMQ REQ/REP + 状态订阅客户端基类。

所有设备的 ZMQ 通信都通过本模块：
  - 命令通道：DEALER socket（REQ/REP via ROUTER-DEALER proxy）
  - 状态通道：SUB socket，CONFLATE=1（仅保留最新帧）

设备类不直接持有 zmq.Context；构造 BaseZMQClient 时通过参数指定端口和 topic。
"""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Any
from uuid import uuid4

import zmq

from parm_sdk.api.exceptions import ParmAPIError

_LOGGER = logging.getLogger("parm_sdk.sdk.transport")

# 状态帧新鲜度阈值（秒）。超过此时间无新帧视为过期。
_STATUS_STALENESS_S = 0.5

# 状态订阅循环的 RCVTIMEO（毫秒）。越小越快检测到停止，越大越省 CPU。
_SUB_RCVTIMEO_MS = 100


class BaseZMQClient:
    """所有设备共用的 ZMQ 客户端基类。

    通过构造参数指定 host/port/topic_prefix，设备类不直接持有 zmq.Context。
    """

    def __init__(
        self,
        host: str = "localhost",
        cmd_port: int = 5600,
        status_port: int | None = None,
        topic_prefix: str = "parm_driver.state",
        identity: bytes | None = None,
        req_timeout_ms: int = 1000,
        cmd_init_timeout: float = 2.0,
    ) -> None:
        self._host = host
        self._cmd_port = cmd_port
        self._status_port = status_port
        self._topic_prefix = topic_prefix
        self._req_timeout_ms = req_timeout_ms
        self._cmd_init_timeout = cmd_init_timeout
        self._closed = False
        self._lock = threading.Lock()

        # 命令 socket
        self._ctx = zmq.Context.instance()
        self._identity = identity or uuid4().bytes
        self._req_socket = self._ctx.socket(zmq.DEALER)
        self._req_socket.setsockopt(zmq.IDENTITY, self._identity)
        self._req_socket.setsockopt(zmq.SNDTIMEO, req_timeout_ms)
        self._req_socket.setsockopt(zmq.RCVTIMEO, req_timeout_ms)
        self._req_socket.connect(f"tcp://{host}:{cmd_port}")

        # 状态订阅
        self._subscriber: _StateSubscriber | None = None
        if status_port is not None:
            self._subscriber = _StateSubscriber(
                ctx=self._ctx,
                host=host,
                port=status_port,
                topic_prefix=topic_prefix,
                wait_timeout=cmd_init_timeout,
            )

    # —— REQ/REP ——

    def send_payload(
        self,
        payload: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """发送任意外部组装好的 JSON 负载并阻塞等待响应。

        与 :meth:`send_command` 的区别：本方法不假设 wire 形态为
        ``{"cmd": ..., "args": {...}}``，直接将入参 dict 序列化发送。
        适用于 wire 形态非标的设备（如 Head 平铺字段、Gripper 包壳）。

        Args:
            payload: 完整的 wire payload（调用方自行组装）。
            timeout: 超时秒数。None = 使用构造时的 req_timeout_ms。

        Returns:
            dict：响应解析后的 JSON。

        Raises:
            ParmAPIError: 超时、socket 错误、响应非合法 JSON、
                响应 ``success=false``（Head/Arm 协议）或 ``status="error"``
                （Gripper 协议）。
        """
        if self._closed:
            raise ParmAPIError("client closed")

        payload_bytes = json.dumps(payload).encode("utf-8")

        with self._lock:
            if timeout is not None:
                self._req_socket.setsockopt(zmq.SNDTIMEO, int(timeout * 1000))
                self._req_socket.setsockopt(zmq.RCVTIMEO, int(timeout * 1000))
            try:
                self._req_socket.send_multipart([b"", payload_bytes])
                reply = self._req_socket.recv_multipart()
            except zmq.Again:
                # recv 超时（或 send 撞上 SNDTIMEO）。server 可能已经在超时前
                # 把回复发回来并缓存在 socket 里；如果不重建，下一次 recv 会把
                # 这条陈旧回复错配给新请求（off-by-one 关联错位）。
                self._reset_req_socket()
                raise ParmAPIError(
                    "timeout waiting for response",
                    error_code=1007,
                ) from None
            except zmq.ZMQError as e:
                self._reset_req_socket()
                raise ParmAPIError(f"socket error: {e}") from e

        try:
            response = json.loads(reply[-1])
        except (json.JSONDecodeError, IndexError) as e:
            raise ParmAPIError(f"invalid response: {e}") from e

        # Head/Arm: success=false
        if response.get("success") is False:
            raise ParmAPIError(
                response.get("message", "unknown error"),
                error_code=response.get("code", 1),
            )

        # Gripper: status="error"
        if response.get("status") == "error":
            err = response.get("error") or {}
            message = err.get("message", "unknown error")
            raise ParmAPIError(
                f"[{err.get('code', 'UNKNOWN')}] {message}",
                error_code=1,
            )

        return response

    def send_command(
        self,
        cmd: str,
        args: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
        raw_data: bool = False,
    ) -> dict | str:
        """发送命令并阻塞等待响应（适用于 Arm-style wire）。

        Args:
            cmd: wire name（与各设备 C++ 端 CommandType 枚举的字符串一致）。
            args: 命令参数（dict）。None 等价于空 dict。
            timeout: 超时秒数。None = 使用构造时的 req_timeout_ms。
            raw_data: True 时返回响应中 data 字段的原始字符串（用于 get_version/query_log）。

        Returns:
            dict：响应解析后的 JSON（raw_data=False）。
            str：data 字段的原始字符串（raw_data=True）。

        Raises:
            ParmAPIError: 服务端返回 success=false、超时、socket 错误或响应非合法 JSON。
        """
        response = self.send_payload({"cmd": cmd, "args": args or {}}, timeout=timeout)

        if raw_data:
            return response.get("data", "")

        return response

    # —— 服务可用性探测 ——

    @staticmethod
    def is_server_available(host: str, port: int, timeout: float = 0.1) -> bool:
        """探测指定 host:port 是否有服务在监听。"""
        import socket as _socket
        try:
            with _socket.create_connection((host, port), timeout=timeout):
                return True
        except (OSError, _socket.timeout):
            return False

    # —— 状态订阅 ——

    def get_state(self) -> dict | None:
        """返回最新状态帧的 dict 副本。None 表示未就绪或已过期。"""
        if self._subscriber is None:
            return None
        return self._subscriber.get_latest()

    def wait_first_status(self, timeout: float = 2.0) -> dict:
        """阻塞等到第一帧状态。超时或 client 未启用状态订阅时抛错。"""
        if self._subscriber is None:
            raise ParmAPIError("status subscriber not enabled")
        return self._subscriber.wait_first(timeout)

    # —— 生命周期 ——

    def _reset_req_socket(self) -> None:
        """关闭并重建命令 socket（带新 identity），丢弃任何残留状态。

        触发场景：recv 超时（RCVTIMEO 过期）。server 在超时前可能已经把
        回复发回来并缓存在 socket 里；如果不重置，下一次 recv 会把这条
        陈旧回复错配给下一个调用者，造成 request/response 错位（off-by-one）。

        用全新 identity 而非保留旧的：让 server 的 ROUTER 把后续到达的
        旧回复视为"客户端已下线"并丢弃，避免迟到回复仍被路由到新 socket。
        """
        try:
            self._req_socket.close(linger=0)
        except zmq.ZMQError:
            pass
        self._identity = uuid4().bytes
        self._req_socket = self._ctx.socket(zmq.DEALER)
        self._req_socket.setsockopt(zmq.IDENTITY, self._identity)
        self._req_socket.setsockopt(zmq.SNDTIMEO, self._req_timeout_ms)
        self._req_socket.setsockopt(zmq.RCVTIMEO, self._req_timeout_ms)
        self._req_socket.connect(f"tcp://{self._host}:{self._cmd_port}")

    def close(self) -> None:
        """关闭 client。幂等。"""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            if self._subscriber is not None:
                self._subscriber.stop()
            try:
                self._req_socket.close(linger=0)
            except zmq.ZMQError:
                pass

    def __enter__(self) -> "BaseZMQClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


class _StateSubscriber:
    """后台线程订阅 PUB socket，缓存最新一帧状态。

    帧协议：`<topic> <json>` (UTF-8)，空格切分 topic 与 payload。
    使用 CONFLATE=1 保证只保留最新帧。
    """

    def __init__(
        self,
        ctx: zmq.Context,
        host: str,
        port: int,
        topic_prefix: str,
        wait_timeout: float,
    ) -> None:
        self._socket = ctx.socket(zmq.SUB)
        self._socket.setsockopt(zmq.CONFLATE, 1)
        self._socket.setsockopt(zmq.RCVHWM, 1)
        self._socket.setsockopt(zmq.RCVTIMEO, _SUB_RCVTIMEO_MS)
        self._socket.setsockopt(zmq.SUBSCRIBE, topic_prefix.encode("utf-8"))
        self._socket.connect(f"tcp://{host}:{port}")

        self._topic_prefix = topic_prefix
        self._wait_timeout = wait_timeout
        self._cache: dict | None = None
        self._last_seen_monotonic: float | None = None
        self._lock = threading.Lock()
        self._first_frame_event = threading.Event()

        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

        if not self._first_frame_event.wait(timeout=wait_timeout):
            self.stop()
            raise ParmAPIError(
                f"timeout waiting for first status frame on tcp://{host}:{port}"
            )

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                raw = self._socket.recv()
            except zmq.Again:
                continue
            except zmq.ZMQError:
                return
            try:
                text = raw.decode("utf-8")
                topic, _, payload = text.partition(" ")
                if topic != self._topic_prefix:
                    continue
                data = json.loads(payload)
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            with self._lock:
                self._cache = data
                self._last_seen_monotonic = time.monotonic()
                self._first_frame_event.set()

    def get_latest(self) -> dict | None:
        with self._lock:
            if self._last_seen_monotonic is None:
                return None
            if time.monotonic() - self._last_seen_monotonic > _STATUS_STALENESS_S:
                return None
            return dict(self._cache)

    def wait_first(self, timeout: float) -> dict:
        if self._first_frame_event.wait(timeout=timeout):
            with self._lock:
                return dict(self._cache)
        raise ParmAPIError("timeout waiting for first status frame")

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=2)
        try:
            self._socket.close(linger=0)
        except zmq.ZMQError:
            pass