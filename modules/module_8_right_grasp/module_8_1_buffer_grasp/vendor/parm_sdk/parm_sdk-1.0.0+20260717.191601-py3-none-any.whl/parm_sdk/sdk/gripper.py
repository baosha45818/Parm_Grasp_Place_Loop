"""Gripper（多夹爪）高级 API。

支持三个核心动作：get_state（按手索引的状态快照）、init、move（同步/异步）。
Gripper wire 形态是 wrapper：``{"action":..., "device_id":..., "mode":...,
"request_id":..., "timeout":..., "preempt":..., "args":{...}}``，由本类内部
组装后调 :meth:`BaseZMQClient.send_payload`。

v5 公共契约采用 SDK 层"手"命名（``1`` / ``2``，与 Arm 的 ``arm_id``
约定一致：1=左、2=右）。SDK 层手名到 wire 层 device_id 的映射由构造
keyword-only 参数 ``hand_1_device`` / ``hand_2_device`` 配置（默认
``"hit_left"`` / ``"ag_right"``），需要全局调整（例如硬件左右装反）时在构造点
显式覆盖。init / move 接受 ``hand_name``，先经 :meth:`_resolve_hand` 校验并
翻译为 wire 层 ``device_id`` 再发送。

``move()`` 在两种 mode 下统一返回完整 wire envelope dict（``status``、
``data``、``request_id``、``device_id``、``timestamp``）。sync 模式下
``status="success"`` 且包含 ``data``；async 模式下 ``status="accepted"`` 且
通常不含 ``data``。``status="error"`` 时 `send_payload` 已经统一解析为
``ParmAPIError``。
"""

from __future__ import annotations

import logging
from typing import Any

from parm_sdk.api.exceptions import ParmAPIError
from parm_sdk.sdk.transport import BaseZMQClient

_LOGGER = logging.getLogger("parm_sdk.sdk.gripper")

_SERVER_AVAILABLE_TIMEOUT_S = 0.1

# 参数范围（依据 docs/sdk_docs/gripper.md §统一计量单位）
_POSITION_RANGE = (0.0, 100.0)
_FORCE_RANGE = (20.0, 100.0)
_SPEED_RANGE = (1.0, 100.0)
_VALID_MODES = ("sync", "async")

# sync 模式默认超时（秒）。move / init 在 sync 模式下要等设备到达终态，
# 真实硬件 + 力控保护 + 慢速档位下 30s 偏紧；默认给 60s 兜底，调用方仍可
# 通过 ``timeout=`` 显式覆盖。
_DEFAULT_SYNC_TIMEOUT_S = 60.0

# SDK 层手名常量（公共契约）。1=左手、2=右手，与 Arm.arm_id 约定一致。
_HAND_1 = 1
_HAND_2 = 2
_VALID_HANDS = (_HAND_1, _HAND_2)


class Gripper:
    """多夹爪同步 API（v5 —— 手名改为 1 / 2）。"""

    def __init__(
        self,
        host: str = "localhost",
        cmd_port: int = 7701,
        status_port: int = 7702,
        topic_prefix: str = "gripper.state",
        cmd_init_timeout: float = 2.0,
        *,
        hand_1_device: str = "ag_right",
        hand_2_device: str = "hit_left",
    ) -> None:
        if not BaseZMQClient.is_server_available(
            host, cmd_port, timeout=_SERVER_AVAILABLE_TIMEOUT_S
        ):
            raise ParmAPIError(
                f"no server listening at tcp://{host}:{cmd_port}",
                error_code=2003,
            )

        self._hand_1_device = hand_1_device
        self._hand_2_device = hand_2_device

        self._client = BaseZMQClient(
            host=host,
            cmd_port=cmd_port,
            status_port=status_port,
            topic_prefix=topic_prefix,
            cmd_init_timeout=cmd_init_timeout,
        )

    # —— 公共接口 ——

    def _get_state(self) -> dict | None:
        """私有：访问底层 ``BaseZMQClient`` 的 PUB 缓存帧。

        不属于 Gripper 公共 API —— 公共查询请用 :meth:`get_state`。
        仅在确实需要 PUB 缓存的边缘场景下使用。
        """
        return self._client.get_state()

    def get_state(self) -> dict[int, dict | None]:
        """查询所有"手"的状态快照。

        返回 ``{1: state_or_None, 2: state_or_None}``。
        两个 key 始终存在；该手对应的 wire 设备不在总线上、或返回的快照中
        没有该设备时，value 为 ``None``。

        服务端 ``data`` 顶层另有 ``device_names`` 字段（= ``state.keys()``，
        冗余），SDK 忽略——不暴露给调用方。state dict 来自 server 的 per-device
        字段，已剔除冗余的 ``device_id``（可由手名反查得到）。

        Wire 层不在配置手名映射内的设备（例如临时挂载的额外夹爪）会被跳过，
        并通过 :data:`_LOGGER` 打印 warning —— 不影响本调用返回值。
        """
        response = self._send(
            action="get_status",
            device_id="",
            mode="sync",
            request_id=None,
            timeout=_DEFAULT_SYNC_TIMEOUT_S,
            preempt=False,
        )
        data = response.get("data") or {}
        state_map = data.get("state") or {}

        result: dict[int, dict | None] = {_HAND_1: None, _HAND_2: None}

        for wire_id, raw_state in state_map.items():
            if wire_id == self._hand_1_device:
                result[_HAND_1] = _strip_device_id(raw_state)
            elif wire_id == self._hand_2_device:
                result[_HAND_2] = _strip_device_id(raw_state)
            else:
                _LOGGER.warning(
                    "unmapped gripper device %r (not in hand_1_device/hand_2_device config)",
                    wire_id,
                )

        return result

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "Gripper":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # —— 私有辅助 ——

    def _send(
        self,
        action: str,
        device_id: str,
        args: dict[str, Any] | None = None,
        *,
        mode: str = "sync",
        request_id: str | None = None,
        timeout: float = _DEFAULT_SYNC_TIMEOUT_S,
        preempt: bool = False,
    ) -> dict[str, Any]:
        """组装 Gripper wire payload 并发送。

        Gripper wire 字段是 wrapper 形式（不是 Arm 的 {cmd, args}）。

        注意：``timeout`` 同时下发给 server（作为命令执行超时）和作为
        ``send_payload`` 的客户端 RCVTIMEO。必须显式传给 send_payload——
        否则 client socket 会沿用 BaseZMQClient 构造时的 1s 默认值，
        move 等真实动作几乎一定 > 1s，会立刻撞 zmq.Again 然后抛
        "timeout waiting for response"。
        """
        payload = {
            "action": action,
            "device_id": device_id,
            "mode": mode,
            "request_id": request_id or "",
            "timeout": timeout,
            "preempt": preempt,
            "args": args or {},
        }
        return self._client.send_payload(payload, timeout=timeout)

    def _resolve_hand(self, hand_name: int) -> str:
        """校验 ``hand_name`` 并翻译为 wire 层 ``device_id``。

        Raises:
            ValueError: ``hand_name`` 不是 ``1`` 或 ``2``。
        """
        if (
            not isinstance(hand_name, int)
            or isinstance(hand_name, bool)
            or hand_name not in _VALID_HANDS
        ):
            raise ValueError(
                f"hand_name must be one of {_VALID_HANDS}, got {hand_name!r}"
            )
        if hand_name == _HAND_1:
            return self._hand_1_device
        return self._hand_2_device

    @staticmethod
    def _validate_position(position: float) -> None:
        if not isinstance(position, (int, float)) or isinstance(position, bool):
            raise ValueError(f"position must be a number, got {type(position).__name__}")
        if not _POSITION_RANGE[0] <= float(position) <= _POSITION_RANGE[1]:
            raise ValueError(
                f"position must be in [{_POSITION_RANGE[0]}, {_POSITION_RANGE[1]}], got {position}"
            )

    @staticmethod
    def _validate_force(force: float | None) -> None:
        if force is None:
            return
        if not isinstance(force, (int, float)) or isinstance(force, bool):
            raise ValueError(f"force must be a number or None, got {type(force).__name__}")
        if not _FORCE_RANGE[0] <= float(force) <= _FORCE_RANGE[1]:
            raise ValueError(
                f"force must be in [{_FORCE_RANGE[0]}, {_FORCE_RANGE[1]}], got {force}"
            )

    @staticmethod
    def _validate_speed(speed: float | None) -> None:
        if speed is None:
            return
        if not isinstance(speed, (int, float)) or isinstance(speed, bool):
            raise ValueError(f"speed must be a number or None, got {type(speed).__name__}")
        if not _SPEED_RANGE[0] <= float(speed) <= _SPEED_RANGE[1]:
            raise ValueError(
                f"speed must be in [{_SPEED_RANGE[0]}, {_SPEED_RANGE[1]}], got {speed}"
            )

    @staticmethod
    def _validate_mode(mode: str) -> None:
        if mode not in _VALID_MODES:
            raise ValueError(f"mode must be one of {_VALID_MODES}, got {mode!r}")

    # —— 业务方法 ——

    def init(
        self,
        hand_name: int,
        *,
        timeout: float = _DEFAULT_SYNC_TIMEOUT_S,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """初始化指定手对应的夹爪。强制同步执行。

        Args:
            hand_name: SDK 层手名（``1`` 或 ``2``，1=左、2=右）。
            timeout: 命令超时秒数（默认 60，sync 模式）。
            request_id: 客户端请求关联 ID，便于日志追踪。

        Returns:
            ``data`` 字段 ``{"initialized": true}``。

        Raises:
            ValueError: ``hand_name`` 不是合法手名。
        """
        wire_device = self._resolve_hand(hand_name)
        response = self._send(
            action="init",
            device_id=wire_device,
            mode="sync",
            request_id=request_id,
            timeout=timeout,
            preempt=False,
        )
        return response.get("data", {})

    def move(
        self,
        hand_name: int,
        position: float,
        *,
        force: float | None = None,
        speed: float | None = None,
        mode: str = "sync",
        preempt: bool = False,
        timeout: float = _DEFAULT_SYNC_TIMEOUT_S,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """移动手对应的夹爪到目标开度。

        Args:
            hand_name: SDK 层手名（``1`` 或 ``2``，1=左、2=右）。
            position: 目标开度百分比（0-100，0=完全闭合，100=完全打开）。
            force: 力度百分比（20-100，可选；None=不修改寄存器）。
            speed: 速度（1-100，可选；AG 设备不支持）。
            mode: "sync" 等待到终态；"async" 提交后立即返回 accepted。
            preempt: 是否抢占设备当前正在执行的旧任务。
            timeout: 命令超时秒数（默认 60，sync 模式）。
            request_id: 客户端请求关联 ID，便于日志追踪。``None`` 表示由
                服务端在响应中回填空字符串。

        Returns:
            完整 wire envelope dict（sync 与 async 共用同一形状）：键集为
            ``{"status", "data", "request_id", "device_id", "timestamp"}``。

            - ``status="success"``（sync 终态）：包含 ``data`` 字段，含
              ``device_id`` / ``initialized`` / ``motion_state`` / ``position``
              等最终状态。
            - ``status="accepted"``（async 提交即返）：通常不含 ``data``。
            - 异步执行过程中如需查询实时状态，调用方应轮询
              :meth:`get_state`。
        """
        wire_device = self._resolve_hand(hand_name)
        self._validate_position(position)
        self._validate_force(force)
        self._validate_speed(speed)
        self._validate_mode(mode)

        args: dict[str, Any] = {"position": float(position)}
        if force is not None:
            args["force"] = float(force)
        if speed is not None:
            args["speed"] = float(speed)

        return self._send(
            action="move",
            device_id=wire_device,
            args=args,
            mode=mode,
            request_id=request_id,
            timeout=timeout,
            preempt=preempt,
        )


def _strip_device_id(state: dict[str, Any]) -> dict[str, Any]:
    """从 per-device state dict 中剔除冗余的 ``device_id`` 字段。

    ``device_id`` 在 ``get_state()`` 的返回里已由手名取代，故剔除以避免
    与手名不一致时造成误解。
    """
    return {k: v for k, v in state.items() if k != "device_id"}


__all__ = ["Gripper"]