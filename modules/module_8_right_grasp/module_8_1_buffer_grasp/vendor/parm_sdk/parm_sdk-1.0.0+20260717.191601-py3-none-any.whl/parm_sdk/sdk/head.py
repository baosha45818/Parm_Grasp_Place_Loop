"""Head（PTZ 云台）高级 API。

提供 ping / init / home / move_to / look_left / look_right / nod /
shake / emergency_stop / shutdown 等指令，并支持状态订阅。

Head 的 wire 形态与 Arm 不同：参数直接平铺在 payload 顶层
（``{"cmd":"move_to","pitch":0,"yaw":15}``），不走嵌套 ``args``。
因此 Head 类内部组装 payload 后调
:meth:`BaseZMQClient.send_payload`，而不是 ``send_command``。

构造时探测端口可用性，并阻塞等到首帧状态（如果 ``status_port`` 已指定）。
"""

from __future__ import annotations

import logging
from typing import Any

from parm_sdk.api.exceptions import ParmAPIError
from parm_sdk.sdk.transport import BaseZMQClient

_LOGGER = logging.getLogger("parm_sdk.sdk.head")

_SERVER_AVAILABLE_TIMEOUT_S = 0.1

# pitch / yaw 范围（依据 docs/sdk_docs/head.md）
_PITCH_RANGE = (-45.0, 45.0)
_YAW_RANGE = (-60.0, 60.0)

# 各命令推荐超时。``BaseZMQClient`` 默认 1s 对单步命令够用，但
# nod/shake 在 server 端做 6 段子动作 + sleep，实测 ~2s，默认会撞超时。
_DEFAULT_CMD_TIMEOUT_S = 30.0
_LONG_CMD_TIMEOUT_S = 10.0
_LONG_CMDS = frozenset({"nod", "shake"})

# ``get_state()`` 返回 frame 的白名单：服务端硬编码 / 冗余字段被屏蔽。
# 详见 ``_filter_head_state`` docstring。
_HEAD_TOP_KEYS: tuple[str, ...] = ("timestamp", "pitch", "yaw", "controller")
_JOINT_KEYS: tuple[str, ...] = ("position", "enabled", "alarm_message")
_CONTROLLER_KEYS: tuple[str, ...] = ("is_moving",)


class Head:
    """云台同步 API。"""

    def __init__(
        self,
        host: str = "localhost",
        cmd_port: int = 7705,
        status_port: int = 7706,
        topic_prefix: str = "parm_driver.state",
        cmd_init_timeout: float = 2.0,
    ) -> None:
        if not BaseZMQClient.is_server_available(
            host, cmd_port, timeout=_SERVER_AVAILABLE_TIMEOUT_S
        ):
            raise ParmAPIError(
                f"no server listening at tcp://{host}:{cmd_port}",
                error_code=2003,
            )

        self._client = BaseZMQClient(
            host=host,
            cmd_port=cmd_port,
            status_port=status_port,
            topic_prefix=topic_prefix,
            cmd_init_timeout=cmd_init_timeout,
        )

    # —— 公共接口 ——

    def get_state(self) -> dict | None:
        frame = self._client.get_state()
        return _filter_head_state(frame)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "Head":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # —— 私有辅助 ——

    def _send(self, cmd: str, **top_level_fields: Any) -> None:
        """组装 Head wire payload 并发送。

        所有参数平铺到 payload 顶层（wire 不使用 args）。

        超时按 cmd 选择：``nod``/``shake`` 在 server 端做多段子动作耗时 ~2s，
        默认 1s 会撞超时，所以单独给到 10s；其余命令用默认 30s 兜底。
        """
        payload = {"cmd": cmd, **top_level_fields}
        timeout = _LONG_CMD_TIMEOUT_S if cmd in _LONG_CMDS else _DEFAULT_CMD_TIMEOUT_S
        self._client.send_payload(payload, timeout=timeout)

    # —— 业务方法 ——

    def ping(self) -> None:
        """连通性测试。"""
        self._send("ping")

    def init(self) -> None:
        """连接串口、使能电机、松刹车、归中锁定。"""
        self._send("init")

    def home(self) -> None:
        """云台归中，pitch=0°，yaw=0°。"""
        self._send("home")

    def move_to(self, pitch: float = 0.0, yaw: float = 0.0) -> None:
        """移动到指定角度。

        坐标系为标准右手系：X 朝前、Z 朝上、Y 朝左。
        pitch 绕 Y 轴旋转（正值抬头），yaw 绕 Z 轴旋转（正值向左）。

        Args:
            pitch: 俯仰角，范围 -45°~+45°。
            yaw: 偏航角，范围 -60°~+60°。
        """
        if not isinstance(pitch, (int, float)):
            raise ValueError(f"pitch must be a number, got {type(pitch).__name__}")
        if not _PITCH_RANGE[0] <= float(pitch) <= _PITCH_RANGE[1]:
            raise ValueError(
                f"pitch must be in [{_PITCH_RANGE[0]}, {_PITCH_RANGE[1]}], got {pitch}"
            )
        if not isinstance(yaw, (int, float)):
            raise ValueError(f"yaw must be a number, got {type(yaw).__name__}")
        if not _YAW_RANGE[0] <= float(yaw) <= _YAW_RANGE[1]:
            raise ValueError(
                f"yaw must be in [{_YAW_RANGE[0]}, {_YAW_RANGE[1]}], got {yaw}"
            )
        # 服务端 pitch 方向与 SDK 语义相反（正值本应 = 抬头，实际 = 低头）。
        # 下发前取反补偿；yaw 不受影响。
        self._send("move_to", pitch=-float(pitch), yaw=float(yaw))

    def look_left(self, deg: float = 15.0) -> None:
        """向左转指定角度。"""
        if not isinstance(deg, (int, float)):
            raise ValueError(f"deg must be a number, got {type(deg).__name__}")
        self._send("look_left", deg=float(deg))

    def look_right(self, deg: float = 15.0) -> None:
        """向右转指定角度。"""
        if not isinstance(deg, (int, float)):
            raise ValueError(f"deg must be a number, got {type(deg).__name__}")
        self._send("look_right", deg=float(deg))

    def nod(self, amp: float = 8.0) -> None:
        """点头动作。

        服务端 pitch 方向反转：``amp`` 在 wire 上以相反符号下发。
        """
        if not isinstance(amp, (int, float)):
            raise ValueError(f"amp must be a number, got {type(amp).__name__}")
        if float(amp) <= 0:
            raise ValueError(f"amp must be > 0, got {amp}")
        self._send("nod", amp=-float(amp))

    def shake(self, amp: float = 12.0) -> None:
        """摇头动作。"""
        if not isinstance(amp, (int, float)):
            raise ValueError(f"amp must be a number, got {type(amp).__name__}")
        if float(amp) <= 0:
            raise ValueError(f"amp must be > 0, got {amp}")
        self._send("shake", amp=float(amp))

    def emergency_stop(self) -> None:
        """紧急停止、抱闸、失能。需要重新 init 才能恢复。"""
        self._send("emergency_stop")

    def shutdown(self) -> None:
        """远程关闭云台服务（会先急停再退出）。"""
        self._send("shutdown")


__all__ = ["Head"]



def _filter_head_state(frame: dict[str, Any] | None) -> dict[str, Any] | None:
    """按白名单过滤 Head 服务端 PUB 帧。

    顶层仅保留白名单 _HEAD_TOP_KEYS；``joints`` 块（与 ``pitch``/``yaw`` 重复）
    与 ``camera`` 整块（人脸跟踪，按既定决策不开放）直接丢弃。嵌套层
    ``pitch``、``yaw`` 内仅保留 ``_JOINT_KEYS``（剔除硬编码 ``velocity``）；
    ``controller`` 内仅保留 ``_CONTROLLER_KEYS``（剔除硬编码 ``connected`` /
    ``initialized`` / ``tracking_enabled`` / ``status``）。

    缺失字段静默忽略；``frame`` 为 ``None``（设备未就绪）原样返回。
    """
    if frame is None:
        return None

    out: dict[str, Any] = {}
    if "timestamp" in frame:
        out["timestamp"] = frame["timestamp"]

    for joint in ("pitch", "yaw"):
        sub = frame.get(joint)
        if isinstance(sub, dict):
            out[joint] = {k: sub[k] for k in _JOINT_KEYS if k in sub}
        elif joint in frame:
            # 顶层 key 在白名单内但值不是 dict，按"原键透传"行为保留。
            out[joint] = frame[joint]

    controller = frame.get("controller")
    if isinstance(controller, dict):
        out["controller"] = {
            k: controller[k] for k in _CONTROLLER_KEYS if k in controller
        }

    return out
